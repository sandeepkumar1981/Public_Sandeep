﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntityTask;
using System.Data.Entity;

namespace DataLayerTask
{
    public class MyContext : DbContext
    {
        public MyContext() : base("name=CSTask")
        {
            Database.SetInitializer(new CustomInitializer());
        }

        public DbSet<EntityTaskMaster> Tasks { get; set; }
    }

    public class CustomInitializer : CreateDatabaseIfNotExists<MyContext>
    {
        protected override void Seed(MyContext context)
        {

        }
    }
}
