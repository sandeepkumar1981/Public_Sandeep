﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataLayerTask;
using EntityTask;

namespace BusinessLayerTask
{
    public class BLTask
    {
        public void AddTask(EntityTaskMaster task)
        {
            using (MyContext db = new MyContext())
            {
                db.Tasks.Add(task);
                db.SaveChanges();
            }
        }

        public List<EntityTaskMaster> GetAllTask()
        {
            using (MyContext db = new MyContext())
            {
                return db.Tasks.ToList();
            }
        }

        public EntityTaskMaster GetTask(int ID)
        {
            using (MyContext db = new MyContext())
            {
                return db.Tasks.FirstOrDefault(e => e.TaskID==ID);
            }
        }

        public List<EntityTaskMaster> GetSearchedTask(EntityTaskMaster task)
        {
            using (MyContext db = new MyContext())
            {
                return db.Tasks.Where(e => e.Task == task.Task || e.ParentTaskID == task.ParentTaskID || e.StartDate == task.StartDate || e.EndDate == task.EndDate || e.Priority == task.Priority).ToList();
            }
        }

        public bool UpdateTask(EntityTaskMaster task, int ID)
        {
            using (MyContext db = new MyContext())
            {
                var entity = db.Tasks.FirstOrDefault(e => e.TaskID == ID);
                if (entity == null)
                {
                    return false;
                }
                else
                {
                    entity.Task = task.Task;
                    entity.ParentTaskID = task.ParentTaskID;
                    entity.Priority = task.Priority;
                    entity.StartDate = task.StartDate;
                    entity.EndDate = task.EndDate;
                    entity.EndTask = task.EndTask;
                    db.SaveChanges();
                    return true;
                }
            }
        }

        public bool DeleteTask(int ID)
        {
            using (MyContext db = new MyContext())
            {
                var entity = db.Tasks.FirstOrDefault(e => e.TaskID == ID);
                if (entity != null)
                {
                    db.Tasks.Remove(entity);
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
    }
}
