﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EntityTask
{
    [Table("EntityTaskMaster")]
    public class EntityTaskMaster
    {
        [Key]
        public int TaskID { get; set; }

        public int ParentTaskID { get; set; }

        [StringLength(250)]
        public string Task { get; set; }

        public int Priority { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public bool EndTask { get; set; }
    }
}
