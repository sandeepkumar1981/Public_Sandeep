﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using BusinessLayerTask;

namespace UnitTestTask
{
    [TestFixture]
    public class TaskTest
    {
        private BusinessLayerTask.BLTask objBL = new BusinessLayerTask.BLTask();

        public void GetAllTask()
        {
            var result = objBL.GetAllTask();
            NUnit.Framework.Assert.AreEqual(result.Count, 2);
        }

        public void GetTask()
        {
            var result = objBL.GetTask(1);
            NUnit.Framework.Assert.AreEqual(result.TaskID, 1);
        }
        public void AddTask()
        {
            EntityTask.EntityTaskMaster objtask = new EntityTask.EntityTaskMaster();
            objtask.TaskID = 3;
            objtask.ParentTaskID = 3;
            objtask.Task = "Task 3";
            objtask.Priority = 1;
            objtask.StartDate = DateTime.Now;
            objtask.EndDate = DateTime.Now;
            objtask.EndTask = false;

            objBL.AddTask(objtask);
            NUnit.Framework.Assert.AreEqual(objtask.TaskID, 3);
            NUnit.Framework.Assert.IsNotNull(objtask);
        }

        public void UpdateTask()
        {
            EntityTask.EntityTaskMaster objtask = new EntityTask.EntityTaskMaster();
            objtask.TaskID = 3;
            objtask.ParentTaskID = 3;
            objtask.Task = "Task 3 - Updated";
            objtask.Priority = 1;
            objtask.StartDate = DateTime.Now;
            objtask.EndDate = DateTime.Now;
            objtask.EndTask = false;

            objBL.UpdateTask(objtask,3);
            NUnit.Framework.Assert.IsNotEmpty("3");
            NUnit.Framework.Assert.IsNotNull("3");
        }

        public void DeleteTask()
        {
            objBL.DeleteTask(3);
            NUnit.Framework.Assert.IsNotEmpty("3");
        }
    }
}
